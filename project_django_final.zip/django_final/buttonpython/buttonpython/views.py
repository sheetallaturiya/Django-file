from django.shortcuts import render
from subprocess import run,PIPE
import sys
import requests

def button(request):
	return render(request,'index.html')

def output(request):
	data=requests.get("https://reqres.in/api/users")
	print(data.text)
	data=data.text
	return render(request,'index.html',{'data':data})

def external(request):
	video_file1 = request.POST.get('video_file')
	output_file1 = request.POST.get('output_file')
	out=run([sys.executable,'D://ViolenceDetection-master//Deploy.py',video_file1,output_file1],shell=False,stdout=PIPE)
	print(out)

	return render(request,'index.html',{'data1':out.stdout})


def external1(request):
	ip1 = request.POST.get('ip')
	out1=run([sys.executable,'D://ViolenceDetection-master//Deploy.py',ip1],shell=False,stdout=PIPE)
	print(out1)

	return render(request,'index.html',{'data2':out1.stdout})